# DataIndex
A Haskell package for adding index columns to data files
